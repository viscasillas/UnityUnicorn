chrome.extension.sendMessage({}, function(response) {
	var readyStateCheckInterval = setInterval(function() {
	if (document.readyState === "complete") {
		clearInterval(readyStateCheckInterval);

		// ----------------------------------------------------------
		// This part of the script triggers when page is done loading
		console.log("Hello. This message was sent from scripts/inject.js");
		// ----------------------------------------------------------



$('body').prepend('<canvas id="c" style="width:100%;height:100%;z-index:5000;position:fixed;top:0px;left:0px;"></canvas>');
var c = document.getElementById("c");
var ctx = c.getContext("2d");

//making the canvas full screen
c.height = window.innerHeight;
c.width = window.innerWidth;

//chinese characters - taken from the unicode charset
var chinese = "✦✦✦✦✦";
//converting the string into an array of single characters
chinese = chinese.split("");

var font_size = 10;
var columns = c.width/font_size; //number of columns for the rain
//an array of drops - one per column
var drops = [];
//x below is the x coordinate
//1 = y co-ordinate of the drop(same for every drop initially)
for(var x = 0; x < columns; x++)
drops[x] = 1;

//drawing the characters
function draw()
{
//Black BG for the canvas
//translucent BG to show trail
ctx.fillStyle = "transparent";
ctx.fillRect(0, 0, c.width, c.height);

ctx.fillStyle = "pink"; //green text
ctx.font = font_size + "px arial";
//looping over drops
for(var i = 0; i < drops.length; i++)
{
//a random chinese character to print
var text = chinese[Math.floor(Math.random()*chinese.length)];
//x = i*font_size, y = value of drops[i]*font_size
ctx.fillText(text, i*font_size, drops[i]*font_size);

//sending the drop back to the top randomly after it has crossed the screen
//adding a randomness to the reset to make the drops scattered on the Y axis
if(drops[i]*font_size > c.height && Math.random() > 0.975)
	drops[i] = 0;

//incrementing Y coordinate
drops[i]++;
}
}

setInterval(draw, 33);


function draw2()
{
//Black BG for the canvas
//translucent BG to show trail
ctx.fillStyle = "transparent";
ctx.fillRect(0, 0, c.width, c.height);

ctx.fillStyle = "purple"; //green text
ctx.font = font_size + "px arial";
//looping over drops
for(var i = 0; i < drops.length; i++)
{
//a random chinese character to print
var text = chinese[Math.floor(Math.random()*chinese.length)];
//x = i*font_size, y = value of drops[i]*font_size
ctx.fillText(text, i*font_size, drops[i]*font_size);

//sending the drop back to the top randomly after it has crossed the screen
//adding a randomness to the reset to make the drops scattered on the Y axis
if(drops[i]*font_size > c.height && Math.random() > 0.975)
	drops[i] = 0;

//incrementing Y coordinate
drops[i]++;
}
}

setInterval(draw2, 45);


setInterval(draw, 33);


function draw3()
{
//Black BG for the canvas
//translucent BG to show trail
ctx.fillStyle = "transparent";
ctx.fillRect(0, 0, c.width, c.height);

ctx.fillStyle = "silver"; //green text
ctx.font = font_size + "px arial";
//looping over drops
for(var i = 0; i < drops.length; i++)
{
//a random chinese character to print
var text = chinese[Math.floor(Math.random()*chinese.length)];
//x = i*font_size, y = value of drops[i]*font_size
ctx.fillText(text, i*font_size, drops[i]*font_size);

//sending the drop back to the top randomly after it has crossed the screen
//adding a randomness to the reset to make the drops scattered on the Y axis
if(drops[i]*font_size > c.height && Math.random() > 0.975)
	drops[i] = 0;

//incrementing Y coordinate
drops[i]++;
}
}

setInterval(draw3, 25);


$('body').prepend(`
<img src="http://i67.tinypic.com/4sl1qs.png" style="display:block;width:400px;margin-right:auto;margin-top:100px;z-index:999999999;margin-left:auto;"/>
`);





	}
	}, 10);
});
